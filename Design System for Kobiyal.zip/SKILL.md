---
name: kobiyal-design
description: Use this skill to generate well-branded interfaces and assets for কবিয়াল (kobiyal), the Bengali poetry reading site — either for production or throwaway prototypes/mocks. Contains essential design guidelines, the shell + phase-skin colour token system, type, fonts, and UI kit components for prototyping.
user-invocable: true
---

Read the readme.md file within this skill, and explore the other available files.

Non-negotiables for kobiyal work:
- Bengali only for anything a reader sees; all labels verbatim from `data/strings-bn.json`; all digits in Bengali numerals.
- Never fabricate or approximate Bengali verse — real verse from the kobiyal dataset, or the clearly-marked placeholder block (`VerseBlock placeholder`).
- Colour only via the token system: constant `--shell-*` gallery + swappable `data-skin` phase skins. Never hand-style a phase. Small text on accent uses `--phase-accent-deep`.
- Serif (Noto Serif Bengali) = the work; sans (Hind Siliguri) = the gallery chrome.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view (link `styles.css`, set `data-skin` for reading surfaces). If working on production code, copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
