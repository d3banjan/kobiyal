/* Loads kobiyal component .jsx files into window globals for card HTMLs.
   Requires React UMD + Babel standalone to be loaded first. */
window.loadDS = async function loadDS(paths) {
  for (const p of paths) {
    const res = await fetch(p);
    if (!res.ok) throw new Error("loadDS: cannot fetch " + p);
    let src = await res.text();
    src = src.replace(/^import\s[^\n]*$/gm, "");
    src = src.replace(/^export\s+function\s+(\w+)/gm, "window.$1 = function $1");
    const code = Babel.transform(src, { presets: ["react"] }).code;
    new Function("React", code)(window.React);
  }
};
