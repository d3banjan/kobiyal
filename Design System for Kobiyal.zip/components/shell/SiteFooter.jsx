import React from "react";

/** Constant gallery footer — rights + made lines, micro sans, hairline top. */
export function SiteFooter({ footer = {}, siteName = "কবিয়াল" }) {
  return (
    <footer style={{
      background: "var(--shell-bg)", borderTop: "var(--hairline) solid var(--shell-hairline)",
      fontFamily: "var(--font-ui)", color: "var(--shell-ink-muted)",
      padding: "var(--space-6) var(--gutter-mobile)", display: "grid", gap: "var(--space-2)"
    }}>
      <span style={{ fontFamily: "var(--font-verse)", fontWeight: 600, color: "var(--shell-ink)", fontSize: "var(--text-ui)" }}>{siteName}</span>
      <span style={{ fontSize: "var(--text-micro)", lineHeight: "var(--leading-caption)" }}>{footer.rights}</span>
      <span style={{ fontSize: "var(--text-micro)", lineHeight: "var(--leading-caption)" }}>{footer.made}</span>
    </footer>
  );
}
