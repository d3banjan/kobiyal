import React from "react";

/** Constant gallery chrome — never skinned. Sans wordmark nav, serif brand mark. */
export function SiteHeader({ siteName = "কবিয়াল", nav = {}, active = "home", onNavigate }) {
  const items = ["home", "poets", "themes", "about"].filter(k => nav[k]);
  return (
    <header style={{
      background: "var(--shell-bg)", borderBottom: "var(--hairline) solid var(--shell-hairline)",
      fontFamily: "var(--font-ui)", color: "var(--shell-ink)"
    }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "var(--space-5)", padding: "var(--space-4) var(--gutter-mobile)" }}>
        <a href="#" onClick={e => { e.preventDefault(); onNavigate && onNavigate("home"); }}
          style={{ fontFamily: "var(--font-verse)", fontWeight: 700, fontSize: "1.25rem", color: "var(--shell-ink)", textDecoration: "none", lineHeight: 1 }}>
          {siteName}
        </a>
        <nav style={{ display: "flex", gap: "var(--space-4)", flexWrap: "wrap", justifyContent: "flex-end" }}>
          {items.map(k => (
            <a key={k} href="#" onClick={e => { e.preventDefault(); onNavigate && onNavigate(k); }}
              style={{
                fontSize: "var(--text-caption)", textDecoration: "none", whiteSpace: "nowrap",
                color: active === k ? "var(--shell-ink)" : "var(--shell-ink-muted)",
                borderBottom: active === k ? "1px solid var(--shell-ink)" : "1px solid transparent",
                paddingBottom: 2, transition: "color var(--dur-quick) var(--ease-illuminate)"
              }}>
              {nav[k]}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}
