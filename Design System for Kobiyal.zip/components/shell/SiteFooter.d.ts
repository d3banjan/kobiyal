/** kobiyal site footer — shell chrome. */
export interface SiteFooterProps {
  /** footer strings: { rights, made } */
  footer?: Record<string, string>;
  siteName?: string;
}
