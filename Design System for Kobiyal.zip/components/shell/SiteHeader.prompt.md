Constant near-white gallery header: serif কবিয়াল wordmark + quiet sans nav; never takes a phase skin.

```jsx
<SiteHeader nav={strings.nav} active="poets" onNavigate={setRoute} />
```

Active item gets full ink + 1px underline; others are muted. Pass strings verbatim from `data/strings-bn.json`.
