/**
 * kobiyal site header — constant shell chrome, never skinned.
 */
export interface SiteHeaderProps {
  /** Brand wordmark, default "কবিয়াল" */
  siteName?: string;
  /** nav strings object from strings-bn.json: { home, poets, themes, about } */
  nav?: Record<string, string>;
  /** active nav key */
  active?: "home" | "poets" | "themes" | "about";
  onNavigate?: (key: string) => void;
}
