Quiet gallery footer: wordmark + the two footer strings (rights, made) in micro muted sans above a hairline.

```jsx
<SiteFooter footer={strings.footer} />
```
