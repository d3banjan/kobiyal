/**
 * The signature element: a poet's creative-life timeline. Resting phases are
 * quiet/dim; the active phase illuminates in its own skin. Parallel strands
 * (chronological: false) are offset with a diamond marker + dashed connector.
 * @startingPoint section="Components" subtitle="Phase timeline — resting + illuminated states" viewport="390x560"
 */
export interface PhaseTimelineProps {
  phases: Array<{
    /** skin id matching tokens/colors.css, e.g. "banalata-sen" */
    id: string;
    /** Bengali phase label, e.g. "বনলতা সেন — সন্ধ্যা ও অনন্ত" */
    label: string;
    /** Bengali motif line shown when illuminated */
    motif?: string;
    /** poem count in this phase */
    count?: number;
    /** false = parallel strand (e.g. রূপসী বাংলা) */
    chronological?: boolean;
  }>;
  /** id of the illuminated phase; omit for the all-resting state */
  activeId?: string;
  onSelect?: (id: string) => void;
  /** poet strings: { poem_count, strand_label, strand_note } */
  strings?: Record<string, string>;
  /** aria strings: { phase_segment } */
  aria?: Record<string, string>;
}
