/**
 * Home gallery tile for a poet: serif name, Bengali-numeral dates, poem count,
 * and a quiet strip of the poet's phase hues.
 * @startingPoint section="Components" subtitle="Poet gallery tile" viewport="390x200"
 */
export interface PoetCardProps {
  /** Poet name in Bengali, e.g. "জীবনানন্দ দাশ" */
  name: string;
  /** Birth year (Western digits ok — rendered as Bengali numerals) */
  born: number | string;
  /** Death year */
  died: number | string;
  poemCount?: number;
  /** Phase skin ids, in order — renders the hue strip, e.g. ["jhara-palak", …] */
  phases?: string[];
  /** poet strings from strings-bn.json: { born_label, died_label, poem_count } */
  strings?: Record<string, string>;
  onClick?: () => void;
}
