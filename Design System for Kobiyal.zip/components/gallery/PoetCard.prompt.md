Home gallery tile: poet name in serif, জন্ম/মৃত্যু dates + poem count in Bengali numerals, and a strip of the poet's phase accent hues.

```jsx
<PoetCard name="জীবনানন্দ দাশ" born={1899} died={1954} poemCount={48}
  phases={["jhara-palak","dhusar-pandulipi","banalata-sen","mahaprithibi-timir","rupasi-bangla"]}
  strings={strings.poet} onClick={openPoet} />
```

Hover only darkens the hairline — no lift, no scale.
