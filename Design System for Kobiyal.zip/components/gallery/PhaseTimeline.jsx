import React from "react";

/**
 * THE signature element. A vertical spine of a poet's creative phases.
 * Resting: quiet, dim, monochrome. Active: the phase floods with its own skin
 * (data-skin) over --dur-illuminate. Parallel strands (chronological: false)
 * sit offset from the spine with a diamond marker + dashed connector, so the
 * timeline never reads as one false progression.
 */
export function PhaseTimeline({ phases = [], activeId, onSelect, strings = {}, aria = {} }) {
  const bn = s => String(s).replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]);
  const countLabel = c => (strings.poem_count || "{count}টি কবিতা").replace("{count}", bn(c ?? 0));
  return (
    <div style={{ position: "relative", fontFamily: "var(--font-ui)" }}>
      <span aria-hidden="true" style={{ position: "absolute", left: 9, top: 14, bottom: 14, width: 1, background: "var(--shell-hairline)" }}></span>
      <ol style={{ listStyle: "none", margin: 0, padding: 0, display: "grid", gap: "var(--space-2)" }}>
        {phases.map(p => {
          const active = p.id === activeId;
          const parallel = p.chronological === false;
          return (
            <li key={p.id} data-skin={p.id} style={{ position: "relative", marginLeft: parallel ? "var(--space-6)" : 0 }}>
              {parallel && (
                <span aria-hidden="true" style={{ position: "absolute", left: -23, top: 26, width: 20, borderTop: "1px dashed var(--shell-ink-muted)" }}></span>
              )}
              <button type="button" onClick={() => onSelect && onSelect(p.id)}
                aria-label={(aria.phase_segment || "{phase} পর্ব").replace("{phase}", p.label)}
                aria-current={active ? "true" : undefined}
                style={{
                  display: "grid", gridTemplateColumns: "20px 1fr", columnGap: "var(--space-3)",
                  alignItems: "start", width: "100%", textAlign: "start", cursor: "pointer",
                  font: "inherit", border: "none", borderRadius: "var(--radius-card)",
                  padding: "var(--space-3) var(--space-3) var(--space-3) 0",
                  background: active ? "var(--phase-bg)" : "transparent",
                  color: active ? "var(--phase-ink)" : "var(--shell-ink-muted)",
                  boxShadow: active ? "inset 0 0 0 1px var(--phase-hairline)" : "none",
                  transition: "background var(--dur-illuminate) var(--ease-illuminate), color var(--dur-illuminate) var(--ease-illuminate)"
                }}>
                <span aria-hidden="true" style={{
                  justifySelf: "center", marginTop: 8, width: 9, height: 9,
                  transform: parallel ? "rotate(45deg)" : "none",
                  borderRadius: parallel ? 1 : "50%",
                  border: active ? "none" : "1.5px solid var(--shell-ink-muted)",
                  background: active ? "var(--phase-accent)" : "transparent",
                  transition: "background var(--dur-illuminate) var(--ease-illuminate)"
                }}></span>
                <span style={{ display: "grid", gap: "var(--space-1)", padding: "0 var(--space-2)" }}>
                  {parallel && (
                    <span style={{
                      justifySelf: "start", fontSize: "var(--text-micro)", letterSpacing: "0.02em", whiteSpace: "nowrap",
                      color: active ? "var(--phase-accent-deep)" : "var(--shell-ink-muted)",
                      border: "1px " + (active ? "solid var(--phase-hairline)" : "dashed var(--shell-hairline)"),
                      borderRadius: "var(--radius-chip)", padding: "1px var(--space-3)"
                    }}>{strings.strand_label || "সমান্তরাল ধারা"}</span>
                  )}
                  <span style={{
                    fontFamily: "var(--font-verse)", fontWeight: 600, fontSize: "var(--text-phase)",
                    lineHeight: "var(--leading-display)", color: active ? "var(--phase-ink)" : "var(--shell-ink)"
                  }}>{p.label}</span>
                  {p.motif && active && (
                    <span style={{ fontSize: "var(--text-caption)", color: "var(--phase-ink-muted)" }}>{p.motif}</span>
                  )}
                  <span style={{ fontSize: "var(--text-caption)", color: active ? "var(--phase-ink-muted)" : "var(--shell-ink-muted)" }}>
                    {countLabel(p.count)}
                  </span>
                  {parallel && active && strings.strand_note && (
                    <span style={{ fontSize: "var(--text-micro)", lineHeight: "var(--leading-caption)", color: "var(--phase-ink-muted)" }}>{strings.strand_note}</span>
                  )}
                </span>
              </button>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
