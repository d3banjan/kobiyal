The signature element. Vertical spine of a poet's creative phases — resting rows are dim and monochrome; the active row floods with its phase skin (300ms illumination). রূপসী বাংলা-style parallel strands offset right with a diamond marker, dashed connector and a "সমান্তরাল ধারা" tag so the timeline never reads as a single false progression.

```jsx
<PhaseTimeline
  phases={[
    { id: "jhara-palak", label: "ঝরা পালক — ধার-করা স্বর", count: 7, chronological: true },
    { id: "rupasi-bangla", label: "রূপসী বাংলা — সমান্তরাল সবুজ", count: 12, chronological: false },
  ]}
  activeId="jhara-palak"
  onSelect={setPhase}
  strings={strings.poet} aria={strings.aria} />
```

Omit `activeId` for the fully-resting state. Counts render in Bengali numerals automatically.
