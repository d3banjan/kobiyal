import React from "react";

/** Home gallery tile for a poet. Shell-styled, with a quiet strip of the poet's phase hues. */
export function PoetCard({ name, born, died, poemCount, phases = [], strings = {}, onClick }) {
  const bn = s => String(s).replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]);
  const countLabel = (strings.poem_count || "{count}টি কবিতা").replace("{count}", bn(poemCount ?? 0));
  return (
    <a href="#" onClick={e => { e.preventDefault(); onClick && onClick(); }}
      style={{
        display: "grid", gap: "var(--space-2)", textDecoration: "none",
        background: "var(--shell-bg)", border: "var(--hairline) solid var(--shell-hairline)",
        borderRadius: "var(--radius-card)", padding: "var(--space-5)",
        boxShadow: "var(--shadow-card)", color: "var(--shell-ink)",
        transition: "border-color var(--dur-quick) var(--ease-illuminate)"
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--shell-ink-muted)"; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--shell-hairline)"; }}>
      <span style={{ fontFamily: "var(--font-verse)", fontWeight: 600, fontSize: "var(--text-title)", lineHeight: "var(--leading-display)" }}>{name}</span>
      <span style={{ fontFamily: "var(--font-ui)", fontSize: "var(--text-caption)", color: "var(--shell-ink-muted)" }}>
        {strings.born_label || "জন্ম"} {bn(born)} · {strings.died_label || "মৃত্যু"} {bn(died)} · {countLabel}
      </span>
      {phases.length > 0 && (
        <span aria-hidden="true" style={{ display: "flex", gap: "var(--space-1)", marginTop: "var(--space-2)" }}>
          {phases.map(id => (
            <span key={id} data-skin={id} style={{ width: 22, height: 4, borderRadius: 2, background: "var(--phase-accent)", opacity: 0.85 }}></span>
          ))}
        </span>
      )}
    </a>
  );
}
