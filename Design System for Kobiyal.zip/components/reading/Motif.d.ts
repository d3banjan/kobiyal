/**
 * Restrained single-weight line motif (feather / page / bird / stars / river),
 * tinted by currentColor — phase accent inside a skin, graphite in the shell.
 */
export interface MotifProps {
  /** which mark: feather (ঝরা পালক), page (ধূসর পাণ্ডুলিপি), bird (বনলতা সেন), stars (তিমির), river (রূপসী বাংলা) */
  name?: "feather" | "page" | "bird" | "stars" | "river";
  /** px, default 48 */
  size?: number;
  /** CSS color; defaults to var(--phase-accent) */
  color?: string;
  style?: React.CSSProperties;
}
