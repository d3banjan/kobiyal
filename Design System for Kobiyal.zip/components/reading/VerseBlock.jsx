import React from "react";

/**
 * The verse hero — the largest, most cared-for type on the site.
 * stanzas: array of stanzas, each an array of line strings (REAL verse only —
 * never fabricated Bengali). `placeholder` renders a clearly-marked neutral
 * block shaped like verse when real text is unavailable.
 */
export function VerseBlock({ title, stanzas = [], unverified = false, unverifiedLabel = "পাঠ যাচাই চলছে", placeholder = false, placeholderLines = [0.86, 0.7, 0.92, 0.6] }) {
  return (
    <article style={{ maxWidth: "var(--measure-verse)", color: "var(--phase-ink)" }}>
      {title && (
        <h1 style={{
          fontFamily: "var(--font-verse)", fontWeight: 700, fontSize: "var(--text-display)",
          lineHeight: "var(--leading-display)", margin: "0 0 var(--space-6) 0"
        }}>{title}</h1>
      )}
      {unverified && (
        <span style={{
          display: "inline-block", fontFamily: "var(--font-ui)", fontSize: "var(--text-micro)",
          color: "var(--phase-ink-muted)", border: "1px dashed var(--phase-hairline)",
          borderRadius: "var(--radius-chip)", padding: "1px var(--space-3)", marginBottom: "var(--space-5)"
        }}>{unverifiedLabel}</span>
      )}
      {placeholder ? (
        <div aria-label="ভবিষ্যতে যাচাইকৃত পাঠ বসবে" style={{ display: "grid", gap: "var(--space-4)" }}>
          {placeholderLines.map((w, i) => (
            <span key={i} style={{ display: "block", height: "0.9em", width: `${w * 100}%`, background: "var(--phase-ink-faint)", opacity: 0.45, borderRadius: 2, fontSize: "var(--text-verse)" }}></span>
          ))}
        </div>
      ) : (
        <div style={{ display: "grid", gap: "var(--space-6)" }}>
          {stanzas.map((lines, i) => (
            <p key={i} style={{
              fontFamily: "var(--font-verse)", fontWeight: "var(--weight-verse)",
              fontSize: "var(--text-verse)", lineHeight: "var(--leading-verse)",
              margin: 0, textWrap: "pretty"
            }}>
              {lines.map((l, j) => (
                <React.Fragment key={j}>{l}{j < lines.length - 1 && <br />}</React.Fragment>
              ))}
            </p>
          ))}
        </div>
      )}
    </article>
  );
}
