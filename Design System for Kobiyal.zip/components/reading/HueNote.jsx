import React from "react";

/**
 * "রঙের কথা" — the optional one-line why-this-hue micro-note.
 * An accent swatch dot + the motif line, in muted phase ink.
 */
export function HueNote({ label = "রঙের কথা", note }) {
  return (
    <p style={{
      margin: 0, display: "flex", alignItems: "baseline", gap: "var(--space-2)",
      fontFamily: "var(--font-ui)", fontSize: "var(--text-micro)",
      lineHeight: "var(--leading-caption)", color: "var(--phase-ink-muted)"
    }}>
      <span aria-hidden="true" style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--phase-accent)", flex: "none", transform: "translateY(1px)" }}></span>
      <span><span style={{ color: "var(--phase-accent-deep)" }}>{label}</span> — {note}</span>
    </p>
  );
}
