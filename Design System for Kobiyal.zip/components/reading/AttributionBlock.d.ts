/**
 * Attribution beneath a poem: কবি · কাব্যগ্রন্থ · প্রকাশ · সূত্র.
 * Always present (honesty principle). Year renders in Bengali numerals.
 */
export interface AttributionBlockProps {
  poet: string;
  collection?: string;
  /** publication year; auto-converted to Bengali numerals */
  year?: number | string;
  /** source; falls back to strings.source_unknown */
  source?: string;
  /** poem strings: { poet_label, collection_label, year_label, source_label, source_unknown } */
  strings?: Record<string, string>;
}
