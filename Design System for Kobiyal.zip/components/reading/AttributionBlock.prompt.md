Quiet two-column attribution list under every poem — কবি, কাব্যগ্রন্থ, প্রকাশ, সূত্র — above a phase hairline. Attribution is never optional.

```jsx
<AttributionBlock poet="জীবনানন্দ দাশ" collection="বনলতা সেন" year={1942} strings={strings.poem} />
```

Omitting `source` shows "সূত্র অজানা" rather than hiding the row.
