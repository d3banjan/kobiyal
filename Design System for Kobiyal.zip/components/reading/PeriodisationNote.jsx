import React from "react";

/**
 * The periodisation disclaimer — small, calm, honest. Rendered wherever a
 * phase division is shown. Never bold, never boxed loudly.
 */
export function PeriodisationNote({ text = "এই পর্ব-বিভাজন একটি পাঠ — কোনো ধ্রুব সত্য নয়।", tone = "shell" }) {
  const onSkin = tone === "phase";
  return (
    <p style={{
      margin: 0, fontFamily: "var(--font-ui)", fontSize: "var(--text-micro)",
      lineHeight: "var(--leading-caption)",
      color: onSkin ? "var(--phase-ink-muted)" : "var(--shell-ink-muted)",
      paddingLeft: "var(--space-3)",
      borderLeft: "var(--hairline) solid " + (onSkin ? "var(--phase-hairline)" : "var(--shell-hairline)")
    }}>{text}</p>
  );
}
