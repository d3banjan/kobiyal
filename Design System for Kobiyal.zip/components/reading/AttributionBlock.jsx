import React from "react";

/**
 * কবি · কাব্যগ্রন্থ · প্রকাশ · সূত্র — always present beneath a poem.
 * Small, graceful, never shouty. Sans (the gallery speaking), on the skin.
 */
export function AttributionBlock({ poet, collection, year, source, strings = {} }) {
  const bn = s => String(s).replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]);
  const rows = [
    [strings.poet_label || "কবি", poet],
    [strings.collection_label || "কাব্যগ্রন্থ", collection],
    [strings.year_label || "প্রকাশ", year != null ? bn(year) : null],
    [strings.source_label || "সূত্র", source || strings.source_unknown || "সূত্র অজানা"],
  ].filter(([, v]) => v != null);
  return (
    <dl style={{
      margin: 0, padding: "var(--space-5) 0 0 0",
      borderTop: "var(--hairline) solid var(--phase-hairline)",
      fontFamily: "var(--font-ui)", fontSize: "var(--text-caption)",
      lineHeight: "var(--leading-caption)",
      display: "grid", gridTemplateColumns: "max-content 1fr",
      columnGap: "var(--space-5)", rowGap: "var(--space-2)"
    }}>
      {rows.map(([label, value]) => (
        <React.Fragment key={label}>
          <dt style={{ color: "var(--phase-ink-muted)" }}>{label}</dt>
          <dd style={{ margin: 0, color: "var(--phase-ink)" }}>{value}</dd>
        </React.Fragment>
      ))}
    </dl>
  );
}
