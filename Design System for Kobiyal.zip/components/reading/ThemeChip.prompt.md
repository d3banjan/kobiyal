Hairline pill for themes/tags, with optional Bengali-numeral count. `tone="phase"` adapts the hairline + ink to the current skin.

```jsx
<ThemeChip label="অন্ধকার" count={9} onClick={openTheme} />
<ThemeChip label="নদী" tone="phase" />
```
