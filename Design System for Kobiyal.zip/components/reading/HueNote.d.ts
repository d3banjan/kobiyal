/** "রঙের কথা" one-liner: why this phase wears this hue. */
export interface HueNoteProps {
  /** default "রঙের কথা" (strings.phase.why_this_hue) */
  label?: string;
  /** the motif line, e.g. "সন্ধ্যায় ঘরে-ফেরা পাখি; অন্ধকার" */
  note: string;
}
