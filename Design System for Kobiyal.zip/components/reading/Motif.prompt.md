One flat, single-weight line mark per phase — feather, manuscript page, homing bird, star scatter, river line. Tinted via currentColor.

```jsx
<Motif name="bird" size={40} />                      {/* inside a skin: phase accent */}
<Motif name="river" color="var(--shell-motif)" />    {/* resting in the shell */}
```

Use at most ONE motif per surface. Never add new marks outside this set without matching the stroke manner.
