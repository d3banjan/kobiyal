/** Small calm disclaimer that periodisation is a reading, not fact. */
export interface PeriodisationNoteProps {
  /** default: "এই পর্ব-বিভাজন একটি পাঠ — কোনো ধ্রুব সত্য নয়।" */
  text?: string;
  tone?: "shell" | "phase";
}
