import React from "react";

/** Theme/tag chip — quiet sans pill. Works on shell or skin via tone prop. */
export function ThemeChip({ label, count, tone = "shell", onClick }) {
  const bn = s => String(s).replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]);
  const onSkin = tone === "phase";
  return (
    <button type="button" onClick={onClick}
      style={{
        fontFamily: "var(--font-ui)", fontSize: "var(--text-caption)", cursor: "pointer",
        color: onSkin ? "var(--phase-ink)" : "var(--shell-ink)",
        background: "transparent",
        border: "var(--hairline) solid " + (onSkin ? "var(--phase-hairline)" : "var(--shell-hairline)"),
        borderRadius: "var(--radius-chip)", padding: "var(--space-1) var(--space-4)",
        display: "inline-flex", alignItems: "baseline", gap: "var(--space-2)",
        transition: "border-color var(--dur-quick) var(--ease-illuminate)"
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = onSkin ? "var(--phase-accent-deep)" : "var(--shell-ink-muted)"; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = onSkin ? "var(--phase-hairline)" : "var(--shell-hairline)"; }}>
      <span>{label}</span>
      {count != null && (
        <span style={{ color: onSkin ? "var(--phase-ink-muted)" : "var(--shell-ink-muted)", fontSize: "var(--text-micro)" }}>{bn(count)}</span>
      )}
    </button>
  );
}
