One-line micro-note explaining a phase's hue: accent dot + "রঙের কথা — <motif line>". Optional; one per phase surface at most.

```jsx
<HueNote label={strings.phase.why_this_hue} note="তারার ফাঁকে তিমির; বিস্তীর্ণ রাত" />
```
