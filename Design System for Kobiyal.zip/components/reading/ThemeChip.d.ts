/** Theme/tag chip — hairline pill, optional Bengali-numeral count. */
export interface ThemeChipProps {
  /** Bengali tag, e.g. "অন্ধকার" */
  label: string;
  /** optional poem count, auto Bengali numerals */
  count?: number;
  /** "shell" (default) on gallery surfaces, "phase" on a skin */
  tone?: "shell" | "phase";
  onClick?: () => void;
}
