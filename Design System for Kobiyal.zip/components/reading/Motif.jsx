import React from "react";

/* Single-weight, geometric line marks — the visual logic of a sans-serif.
   Tinted by currentColor: use --phase-accent inside a skin, --shell-motif in the shell. */
const MOTIF_PATHS = {
  /* ঝরে-পড়া পালক — falling feather */
  feather: (
    <g>
      <path d="M24 6 C16 14 13 26 14 40" />
      <path d="M14 40 C22 38 30 30 32 18 C28 16 26 10 24 6 Z" />
      <path d="M17 32 L26 26 M16 24 L25 17 M18 16 L24 12" />
    </g>
  ),
  /* ধুলোমাখা পাণ্ডুলিপির পাতা — manuscript page */
  page: (
    <g>
      <rect x="10" y="6" width="26" height="34" rx="1" />
      <path d="M16 15 H30 M16 21 H30 M16 27 H26" />
    </g>
  ),
  /* সন্ধ্যায় ঘরে-ফেরা পাখি — homing bird over a horizon */
  bird: (
    <g>
      <path d="M14 18 C18 14 21 14 24 17 C27 14 30 14 34 18" />
      <path d="M6 34 H42" />
    </g>
  ),
  /* তারার ফাঁকে তিমির — star scatter */
  stars: (
    <g>
      <path d="M24 12 V22 M19 17 H29" />
      <path d="M11 30 V36 M8 33 H14" />
      <path d="M36 28 V34 M33 31 H39" />
    </g>
  ),
  /* ধানসিঁড়ি নদী — river line, kingfisher above */
  river: (
    <g>
      <path d="M6 30 C12 26 16 34 22 30 C28 26 32 34 42 28" />
      <circle cx="33" cy="15" r="2.5" />
    </g>
  ),
};

/** A restrained line motif. One mark per surface — never decorative clutter. */
export function Motif({ name = "feather", size = 48, color, style }) {
  return (
    <svg viewBox="0 0 48 48" width={size} height={size} aria-hidden="true"
      style={{ color: color || "var(--phase-accent)", display: "block", ...style }}
      fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      {MOTIF_PATHS[name] || MOTIF_PATHS.feather}
    </svg>
  );
}
