Micro, muted, hairline-edged note: "এই পর্ব-বিভাজন একটি পাঠ — কোনো ধ্রুব সত্য নয়।" Place under every phase heading.

```jsx
<PeriodisationNote text={strings.poet.phases_disclaimer} />
```
