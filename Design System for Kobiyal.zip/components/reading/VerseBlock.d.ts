/**
 * The verse hero on a phase skin — serif, 1.9 leading, 38rem measure,
 * stanza gaps. Real verse only; placeholder mode for unavailable text.
 * @startingPoint section="Components" subtitle="Poem body — the verse hero" viewport="390x420"
 */
export interface VerseBlockProps {
  /** Poem title in Bengali (serif display) */
  title?: string;
  /** Stanzas: each an array of REAL verse lines. Never fabricate Bengali. */
  stanzas?: string[][];
  /** show the "পাঠ যাচাই চলছে" badge */
  unverified?: boolean;
  unverifiedLabel?: string;
  /** render a clearly-marked neutral block shaped like verse instead of text */
  placeholder?: boolean;
  /** relative line widths (0–1) for placeholder mode */
  placeholderLines?: number[];
}
