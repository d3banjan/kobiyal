The verse hero: Noto Serif Bengali at `--text-verse`, line-height 1.9, 38rem measure, stanza gaps. Sits directly on the phase skin.

```jsx
<VerseBlock title="বনলতা সেন" unverified
  stanzas={[["হাজার বছর ধরে আমি পথ হাঁটিতেছি পৃথিবীর পথে,", "…"]]} />
```

RULES: real verse only — never invented Bengali. If text is unavailable, use `placeholder` (grey bars shaped like verse). Keep the `unverified` badge until the text is checked against print.
