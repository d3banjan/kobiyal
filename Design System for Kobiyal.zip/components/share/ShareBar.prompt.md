Quiet hairline row at the END of a poem: "ছড়িয়ে দিন" (accent-deep pill) + "লেখা টুকে নিন". Surfaces only at genuine arrivals — never timed, never modal-first.

```jsx
<ShareBar strings={strings.share} copied={copied} onShare={openSheet} onCopy={copyText} />
```
