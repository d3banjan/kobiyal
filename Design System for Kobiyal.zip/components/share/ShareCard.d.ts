/**
 * 1080×1350 Instagram share card on a phase skin.
 * @startingPoint section="Components" subtitle="Instagram share card 1080×1350" viewport="540x675"
 */
export interface ShareCardProps {
  /** phase skin id, e.g. "mahaprithibi-timir" */
  skin?: string;
  /** selected REAL verse lines (3–6 reads best) */
  lines?: string[];
  /** credit line, e.g. "জীবনানন্দ দাশ · বনলতা সেন" (strings.share.card_credit template) */
  credit?: string;
  wordmark?: string;
  handle?: string;
  /** a <Motif/> element, tinted by the skin accent */
  motif?: React.ReactNode;
  /** preview scale, e.g. 0.32 */
  scale?: number;
}
