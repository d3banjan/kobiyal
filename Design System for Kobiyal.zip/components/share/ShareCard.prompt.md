The 1080×1350 Instagram card: selected verse on the phase skin, accent rule + poet·collection credit, কবিয়াল wordmark + @kobiyal. Pass a `<Motif/>` for the phase's mark.

```jsx
<ShareCard skin="mahaprithibi-timir" scale={0.32}
  lines={["আমারে দুদণ্ড শান্তি দিয়েছিল নাটোরের বনলতা সেন।"]}
  credit="জীবনানন্দ দাশ · বনলতা সেন"
  motif={<Motif name="stars" size={120} />} />
```

Verify it in BOTH hard skins (dhusar-pandulipi light, mahaprithibi-timir near-black) — if it holds there it holds everywhere.
