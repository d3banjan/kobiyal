import React from "react";

/**
 * 1080×1350 Instagram share card. Selected verse lines on the phase skin,
 * poet · collection credit, কবিয়াল wordmark + handle. Render inside a
 * data-skin wrapper or pass `skin` directly. Use `scale` to preview.
 */
export function ShareCard({ skin, lines = [], credit, wordmark = "কবিয়াল", handle = "@kobiyal", motif = null, scale = 1 }) {
  return (
    <div data-skin={skin} style={{
      width: 1080, height: 1350, transform: `scale(${scale})`, transformOrigin: "top left",
      background: "var(--phase-bg)", color: "var(--phase-ink)",
      display: "flex", flexDirection: "column", justifyContent: "space-between",
      padding: 96, boxSizing: "border-box"
    }}>
      <div style={{ color: "var(--phase-accent)" }}>{motif}</div>
      <div style={{ display: "grid", gap: 48 }}>
        <p style={{
          margin: 0, fontFamily: "var(--font-verse)", fontWeight: 500,
          fontSize: 58, lineHeight: 1.75, textWrap: "pretty"
        }}>
          {lines.map((l, i) => (
            <React.Fragment key={i}>{l}{i < lines.length - 1 && <br />}</React.Fragment>
          ))}
        </p>
        {credit && (
          <p style={{
            margin: 0, fontFamily: "var(--font-ui)", fontSize: 30,
            color: "var(--phase-ink-muted)", display: "flex", alignItems: "center", gap: 20
          }}>
            <span aria-hidden="true" style={{ width: 56, height: 2, background: "var(--phase-accent)", flex: "none" }}></span>
            {credit}
          </p>
        )}
      </div>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
        <span style={{ fontFamily: "var(--font-verse)", fontWeight: 700, fontSize: 40 }}>{wordmark}</span>
        <span style={{ fontFamily: "var(--font-ui)", fontSize: 28, color: "var(--phase-ink-muted)" }}>{handle}</span>
      </div>
    </div>
  );
}
