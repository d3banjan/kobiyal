import React from "react";

/**
 * The tasteful share affordance — surfaces at a genuine arrival (poem end,
 * phase finish). Never timed, never a popup. Quiet hairline row on the skin.
 */
export function ShareBar({ strings = {}, copied = false, onShare, onCopy }) {
  const btn = {
    fontFamily: "var(--font-ui)", fontSize: "var(--text-caption)", cursor: "pointer",
    background: "transparent", color: "var(--phase-ink)",
    border: "var(--hairline) solid var(--phase-hairline)",
    borderRadius: "var(--radius-chip)", padding: "var(--space-2) var(--space-5)", whiteSpace: "nowrap",
    transition: "border-color var(--dur-quick) var(--ease-illuminate)"
  };
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: "var(--space-3)", flexWrap: "wrap",
      paddingTop: "var(--space-5)", borderTop: "var(--hairline) solid var(--phase-hairline)"
    }}>
      <button type="button" style={{ ...btn, color: "var(--phase-accent-deep)", borderColor: "var(--phase-accent-deep)" }} onClick={onShare}>
        {strings.title || "ছড়িয়ে দিন"}
      </button>
      <button type="button" style={btn} onClick={onCopy}>
        {copied ? (strings.copied || "টোকা হয়েছে") : (strings.copy_text || "লেখা টুকে নিন")}
      </button>
    </div>
  );
}
