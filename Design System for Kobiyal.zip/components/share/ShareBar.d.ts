/**
 * Quiet share affordance shown at a genuine arrival — never a popup or timer.
 */
export interface ShareBarProps {
  /** share strings: { title, copy_text, copied } */
  strings?: Record<string, string>;
  /** flips the copy button label to "টোকা হয়েছে" */
  copied?: boolean;
  onShare?: () => void;
  onCopy?: () => void;
}
