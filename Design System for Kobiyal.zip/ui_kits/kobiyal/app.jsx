/* kobiyal site mock — composes the design-system components (window globals
   loaded by ds-loader) against the real strings. */
const { useState, useEffect } = React;
const S = window.KOBIYAL_STRINGS;
const D = window.KOBIYAL_DATA;
const bnDigits = s => String(s).replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]);
const tpl = (t, vars) => Object.entries(vars).reduce((a, [k, v]) => a.replace("{" + k + "}", v), t);

function Heading({ children, tone = "shell" }) {
  return (
    <h2 style={{
      fontFamily: "var(--font-ui)", fontWeight: "var(--weight-ui-strong)", fontSize: "var(--text-caption)",
      color: tone === "phase" ? "var(--phase-ink-muted)" : "var(--shell-ink-muted)",
      margin: 0, paddingBottom: "var(--space-2)",
      borderBottom: "var(--hairline) solid " + (tone === "phase" ? "var(--phase-hairline)" : "var(--shell-hairline)")
    }}>{children}</h2>
  );
}

function HomeScreen({ go }) {
  return (
    <main>
      <div className="col" style={{ display: "grid", gap: "var(--space-7)", padding: "var(--space-8) var(--gutter-mobile)" }}>
        <header style={{ display: "grid", gap: "var(--space-4)" }}>
          <h1 className="hero">{S.home.hero_line}</h1>
          <p className="eyebrow">{S.site.tagline}</p>
          <div style={{ display: "flex", gap: "var(--space-3)", flexWrap: "wrap", marginTop: "var(--space-2)" }}>
            <button className="pill" style={{ border: "var(--hairline) solid var(--shell-ink)", color: "var(--shell-ink)" }} onClick={() => go("poet")}>{S.home.browse_poets}</button>
            <button className="pill" style={{ border: "var(--hairline) solid var(--shell-hairline)", color: "var(--shell-ink)" }} onClick={() => go("theme")}>{S.home.browse_themes}</button>
          </div>
        </header>
        <section style={{ display: "grid", gap: "var(--space-4)" }}>
          <Heading>{S.home.section_poets}</Heading>
          <div style={{ maxWidth: 420 }}>
            <PoetCard name={D.poet.name} born={D.poet.born} died={D.poet.died} poemCount={44}
              phases={D.poet.phases.map(p => p.id)} strings={S.poet} onClick={() => go("poet")} />
          </div>
        </section>
        <section style={{ display: "grid", gap: "var(--space-4)" }}>
          <Heading>{S.home.section_themes}</Heading>
          <div style={{ display: "flex", gap: "var(--space-2)", flexWrap: "wrap" }}>
            {D.themes.map(t => <ThemeChip key={t} label={t} onClick={() => go("theme", { tag: t })} />)}
          </div>
        </section>
      </div>
    </main>
  );
}

function PoetScreen({ go, activePhase, setActivePhase }) {
  const phase = D.poet.phases.find(p => p.id === activePhase);
  const poems = phase ? D.poems.filter(p => p.phase === phase.id) : [];
  return (
    <main>
      <div className="col" style={{ display: "grid", gap: "var(--space-6)", padding: "var(--space-7) var(--gutter-mobile)" }}>
        <header style={{ display: "grid", gap: "var(--space-2)" }}>
          <h1 className="hero">{D.poet.name}</h1>
          <p className="eyebrow">
            {S.poet.born_label} {bnDigits(D.poet.born)} · {S.poet.died_label} {bnDigits(D.poet.died)}
          </p>
        </header>
        <section style={{ display: "grid", gap: "var(--space-4)" }}>
          <Heading>{S.poet.phases_heading}</Heading>
          <PeriodisationNote text={S.poet.phases_disclaimer} />
          <p className="eyebrow" style={{ fontSize: "var(--text-micro)" }}>{S.poet.periodisation_source_label} — {D.poet.periodisationSource}</p>
          <PhaseTimeline phases={D.poet.phases.map(p => ({ id: p.id, label: p.label, motif: p.motif, count: p.count, chronological: p.chronological }))}
            activeId={activePhase} onSelect={setActivePhase} strings={S.poet} aria={S.aria} />
        </section>
      </div>
      {phase && (
        <section className="skin-flood" data-skin={phase.id}>
          <div className="col" style={{ display: "grid", gap: "var(--space-5)", padding: "var(--space-7) var(--gutter-mobile)" }}>
            <Motif name={phase.motifName} size={40} />
            <h2 style={{ fontFamily: "var(--font-verse)", fontWeight: 600, fontSize: "var(--text-title)", lineHeight: "var(--leading-display)", margin: 0 }}>{phase.label}</h2>
            <p className="eyebrow" style={{ color: "var(--phase-ink-muted)" }}>{S.phase.collections_label} — {bnDigits(phase.collection)}</p>
            <HueNote label={S.phase.why_this_hue} note={phase.motif} />
            {!phase.chronological && (
              <p style={{ margin: 0, fontSize: "var(--text-micro)", color: "var(--phase-ink-muted)", lineHeight: "var(--leading-caption)" }}>{S.poet.strand_note}</p>
            )}
            <div style={{ display: "grid", gap: 0, marginTop: "var(--space-2)" }}>
              <Heading tone="phase">{S.phase.poems_in_phase}</Heading>
              {poems.map(p => (
                <button key={p.id} className="poem-row" onClick={() => go("poem", { poem: p.id })}>
                  <span className="t">{p.title}</span>
                  <span className="m">{S.poet.read_poems} →</span>
                </button>
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
}

function ShareSheet({ poem, onClose }) {
  const credit = tpl(S.share.card_credit, { poet: D.poet.name, collection: poem.collection });
  const phase = D.poet.phases.find(p => p.id === poem.phase);
  const scale = Math.min(330, window.innerWidth - 88) / 1080;
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <strong style={{ fontFamily: "var(--font-verse)", fontSize: "var(--text-phase)", fontWeight: 600 }}>{S.share.title}</strong>
          <button className="link-quiet" style={{ color: "var(--shell-ink-muted)" }} onClick={onClose}>{S.util.close}</button>
        </div>
        <p className="eyebrow" style={{ margin: 0 }}>{S.share.select_lines}</p>
        <div style={{ width: 1080 * scale, height: 1350 * scale, overflow: "hidden", boxShadow: "var(--shadow-card)", justifySelf: "center" }}>
          <ShareCard skin={poem.phase} scale={scale} lines={poem.shareLines} credit={credit}
            wordmark={S.share.card_footer} handle={S.site.handle}
            motif={<Motif name={phase.motifName} size={110} color="currentColor" />} />
        </div>
        <div style={{ display: "flex", gap: "var(--space-2)", flexWrap: "wrap" }}>
          <button className="pill" style={{ border: "var(--hairline) solid var(--shell-ink)" }}>{S.share.generate}</button>
          <button className="pill" style={{ border: "var(--hairline) solid var(--shell-hairline)" }}>{S.share.download}</button>
          <button className="pill" style={{ border: "var(--hairline) solid var(--shell-hairline)" }}>{S.share.to_instagram}</button>
        </div>
      </div>
    </div>
  );
}

function PoemScreen({ go, poemId }) {
  const poem = D.poems.find(p => p.id === poemId) || D.poems[0];
  const phase = D.poet.phases.find(p => p.id === poem.phase);
  const [sheet, setSheet] = useState(false);
  const [copied, setCopied] = useState(false);
  return (
    <main className="skin-flood" data-skin={poem.phase} style={{ minHeight: "60vh" }}>
      <div className="col" style={{ display: "grid", gap: "var(--space-6)", padding: "var(--space-6) var(--gutter-mobile) var(--space-8)" }}>
        <button className="link-quiet" style={{ color: "var(--phase-ink-muted)", justifySelf: "start", whiteSpace: "nowrap" }} onClick={() => go("poet")}>← {S.poem.back_to_poet}</button>
        <Motif name={phase.motifName} size={36} />
        <VerseBlock title={poem.title} stanzas={poem.stanzas} unverified={poem.unverified}
          unverifiedLabel={S.poem.unverified_note} placeholder={!!poem.placeholder} placeholderLines={poem.placeholderLines} />
        <AttributionBlock poet={D.poet.name} collection={poem.collection} year={poem.year} source={poem.source} strings={S.poem} />
        <div style={{ display: "grid", gap: "var(--space-3)" }}>
          <span style={{ fontSize: "var(--text-micro)", color: "var(--phase-ink-muted)" }}>{S.poem.related_themes}</span>
          <div style={{ display: "flex", gap: "var(--space-2)", flexWrap: "wrap" }}>
            {poem.themes.map(t => <ThemeChip key={t} label={t} tone="phase" onClick={() => go("theme", { tag: t })} />)}
          </div>
        </div>
        {poem.shareLines && (
          <ShareBar strings={S.share} copied={copied}
            onShare={() => setSheet(true)}
            onCopy={() => { setCopied(true); setTimeout(() => setCopied(false), 1600); }} />
        )}
      </div>
      {sheet && <ShareSheet poem={poem} onClose={() => setSheet(false)} />}
    </main>
  );
}

function ThemeScreen({ go, tag }) {
  const t = tag || D.themes[0];
  const poems = D.poems.filter(p => p.themes.includes(t));
  return (
    <main>
      <div className="col" style={{ display: "grid", gap: "var(--space-6)", padding: "var(--space-7) var(--gutter-mobile)" }}>
        <header style={{ display: "grid", gap: "var(--space-2)" }}>
          <h1 className="hero" style={{ fontSize: "var(--text-title)" }}>{tpl(S.theme.heading, { tag: t })}</h1>
          <p className="eyebrow">{tpl(S.theme.poem_count, { count: bnDigits(poems.length) })}</p>
        </header>
        <div style={{ display: "grid" }}>
          {poems.length === 0 && <p className="eyebrow">{S.util.no_results}</p>}
          {poems.map(p => (
            <button key={p.id} className="poem-row" style={{ borderTopColor: "var(--shell-hairline)" }} onClick={() => go("poem", { poem: p.id })}>
              <span className="t" style={{ display: "inline-flex", alignItems: "center", gap: "var(--space-3)" }}>
                <span data-skin={p.phase} aria-hidden="true" style={{ width: 9, height: 9, borderRadius: "50%", background: "var(--phase-accent)" }}></span>
                {p.title}
              </span>
              <span className="m" style={{ color: "var(--shell-ink-muted)" }}>{p.collection}</span>
            </button>
          ))}
        </div>
        <section style={{ display: "grid", gap: "var(--space-4)" }}>
          <Heading>{S.theme.all_themes}</Heading>
          <div style={{ display: "flex", gap: "var(--space-2)", flexWrap: "wrap" }}>
            {D.themes.map(x => <ThemeChip key={x} label={x} count={D.poems.filter(p => p.themes.includes(x)).length} onClick={() => go("theme", { tag: x })} />)}
          </div>
        </section>
      </div>
    </main>
  );
}

function AboutScreen() {
  return (
    <main>
      <div className="col" style={{ display: "grid", gap: "var(--space-5)", padding: "var(--space-7) var(--gutter-mobile)", maxWidth: 720 }}>
        <h1 className="hero" style={{ fontSize: "var(--text-title)" }}>{S.about.heading}</h1>
        <p style={{ margin: 0, fontSize: "var(--text-ui)", lineHeight: "var(--leading-ui)" }}>{S.about.body}</p>
        {[S.about.pd_note, S.about.text_note, S.about.periodisation_note].map((t, i) => (
          <p key={i} style={{ margin: 0, fontSize: "var(--text-caption)", lineHeight: "var(--leading-caption)", color: "var(--shell-ink-muted)", borderLeft: "var(--hairline) solid var(--shell-hairline)", paddingLeft: "var(--space-3)" }}>{t}</p>
        ))}
        <section style={{ display: "grid", gap: "var(--space-3)" }}>
          <Heading>{S.about.credits_label}</Heading>
          <span aria-label="কৃতজ্ঞতার তালিকা যুক্ত হবে" style={{ height: "0.8em", width: "52%", background: "var(--shell-hairline)", borderRadius: 2 }}></span>
        </section>
      </div>
    </main>
  );
}

function App() {
  /* ?screen=poet&phase=banalata-sen / ?screen=poem&poem=<id> / ?screen=theme&tag=<tag>
     A query string pins the state (for canvas artboards); otherwise restore last route. */
  const qs = new URLSearchParams(window.location.search);
  const pinned = qs.has("screen");
  const saved = (() => { try { return JSON.parse(localStorage.getItem("kobiyal-route") || "null"); } catch (e) { return null; } })();
  const initial = pinned
    ? { screen: qs.get("screen"), poem: qs.get("poem") || undefined, tag: qs.get("tag") || undefined }
    : (saved || { screen: "home" });
  const [route, setRoute] = useState(initial);
  const [activePhase, setActivePhase] = useState(pinned ? (qs.get("phase") || null) : (saved && saved.activePhase || "banalata-sen"));
  useEffect(() => {
    if (!pinned) { try { localStorage.setItem("kobiyal-route", JSON.stringify({ ...route, activePhase })); } catch (e) {} }
    window.scrollTo(0, 0);
  }, [route, activePhase]);
  const go = (screen, params) => setRoute({ screen, ...(params || {}) });
  window.kobiyalGo = go;
  window.kobiyalSetPhase = setActivePhase;
  const navKey = { home: "home", poet: "poets", poem: "poets", theme: "themes", about: "about" }[route.screen];
  return (
    <div className="page" data-screen-label={route.screen}>
      <SiteHeader siteName={S.site.name} nav={S.nav} active={navKey}
        onNavigate={k => go(k === "poets" ? "poet" : k === "themes" ? "theme" : k === "about" ? "about" : "home")} />
      {route.screen === "home" && <HomeScreen go={go} />}
      {route.screen === "poet" && <PoetScreen go={go} activePhase={activePhase} setActivePhase={setActivePhase} />}
      {route.screen === "poem" && <PoemScreen go={go} poemId={route.poem} />}
      {route.screen === "theme" && <ThemeScreen go={go} tag={route.tag} />}
      {route.screen === "about" && <AboutScreen />}
      <SiteFooter footer={S.footer} siteName={S.site.name} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
