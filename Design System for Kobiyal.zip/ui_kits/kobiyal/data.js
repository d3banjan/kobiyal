/* kobiyal mock data — strings verbatim from data/strings-bn.json.
   VERSE POLICY: only canonical public-domain Jibanananda lines, flagged
   unverified; poems whose text is not confidently available use
   placeholder blocks (never fabricated Bengali). */

window.KOBIYAL_STRINGS = {
  site: { name: "কবিয়াল", tagline: "বাংলা কবিতার একটি নিভৃত পাঠঘর", handle: "@kobiyal" },
  nav: { home: "প্রথম পাতা", poets: "কবিরা", themes: "বিষয়", about: "আমাদের কথা", search: "অনুসন্ধান", menu: "মেনু" },
  home: {
    hero_line: "বাংলা কবিতা, পড়ার মতো করে সাজানো।",
    browse_poets: "কবি বেছে নিন", browse_themes: "বিষয় ধরে ঘুরুন",
    section_poets: "কবিরা", section_themes: "বিষয়"
  },
  poet: {
    born_label: "জন্ম", died_label: "মৃত্যু",
    phases_heading: "সৃষ্টিজীবনের পর্ব",
    phases_disclaimer: "এই পর্ব-বিভাজন একটি পাঠ — কোনো ধ্রুব সত্য নয়।",
    periodisation_source_label: "পর্ব-বিন্যাস",
    read_poems: "কবিতা পড়ুন", poem_count: "{count}টি কবিতা",
    explore_phase: "এই পর্বে ঢুকুন",
    strand_label: "সমান্তরাল ধারা",
    strand_note: "এই রচনা ধারাবাহিক পর্বের অংশ নয় — একই সময়ে লেখা, অথচ সুর আলাদা।"
  },
  phase: { poems_in_phase: "এই পর্বের কবিতা", collections_label: "কাব্যগ্রন্থ", why_this_hue: "রঙের কথা" },
  poem: {
    poet_label: "কবি", collection_label: "কাব্যগ্রন্থ", year_label: "প্রকাশ",
    source_label: "সূত্র", source_unknown: "সূত্র অজানা",
    back_to_poet: "কবির পাতায় ফিরুন", related_themes: "প্রসঙ্গ",
    share: "ছড়িয়ে দিন", unverified_note: "পাঠ যাচাই চলছে"
  },
  share: {
    title: "ছড়িয়ে দিন",
    select_lines: "যে পঙ্‌ক্তিগুলো ভাগ করতে চান, বেছে নিন",
    generate: "ছবি বানান", download: "ছবি নামিয়ে নিন",
    to_instagram: "ইনস্টাগ্রামে দিন", copy_text: "লেখা টুকে নিন", copied: "টোকা হয়েছে",
    card_footer: "কবিয়াল", card_credit: "{poet} · {collection}"
  },
  theme: { heading: "‘{tag}’ — এই বিষয়ের কবিতা", poem_count: "{count}টি কবিতা", all_themes: "সব বিষয়" },
  about: {
    heading: "আমাদের কথা",
    body: "কবিয়াল বাংলা কবিতার একটি মুক্ত, অবাণিজ্যিক পাঠ-প্রকল্প। এখানে শুধু মুক্ত-স্বত্ব (পাবলিক ডোমেইন) কবিদের রচনা — যত্ন করে, পড়ার মতো করে সাজানো। কবিতা পড়া আর ভাগ করে নেওয়া যেন সুন্দর একটা অভিজ্ঞতা হয়, সেটাই চাওয়া।",
    pd_note: "এই সংকলনের সমস্ত রচনা মুক্ত-স্বত্ব। স্বত্বাধীন কবিদের লেখা এখানে রাখা হয় না।",
    text_note: "পাঠ মুদ্রিত গ্রন্থের সঙ্গে মিলিয়ে যাচাইয়ের কাজ চলমান। ভুল চোখে পড়লে জানাবেন।",
    periodisation_note: "কবিদের সৃষ্টিজীবনকে যে পর্বে ভাগ করা হয়েছে, তা একটি সম্পাদকীয় পাঠ — আলোচনার জন্য, চূড়ান্ত রায় নয়।",
    credits_label: "কৃতজ্ঞতা"
  },
  footer: { rights: "সমস্ত রচনা মুক্ত-স্বত্ব · অবাণিজ্যিক পাঠ-প্রকল্প", made: "বাংলা কবিতার জন্য তৈরি" },
  util: { loading: "একটু দাঁড়ান…", no_results: "কিছু পাওয়া গেল না।", error: "কিছু একটা গন্ডগোল হয়েছে।", back: "ফিরে যান", close: "বন্ধ করুন" },
  aria: {
    open_menu: "মেনু খুলুন", close_menu: "মেনু বন্ধ করুন", share_poem: "এই কবিতা ছড়িয়ে দিন",
    poet_link: "{poet}-এর পাতা", phase_segment: "{phase} পর্ব", home_link: "প্রথম পাতায় যান"
  }
};

window.KOBIYAL_DATA = {
  poet: {
    name: "জীবনানন্দ দাশ", born: 1899, died: 1954,
    periodisationSource: "সম্পাদকীয় পাঠ",
    phases: [
      { id: "jhara-palak", label: "ঝরা পালক — ধার-করা স্বর", motif: "ঝরে-পড়া একটি পালক; অস্তরাগ", motifName: "feather", collection: "ঝরা পালক (১৯২৭)", count: 5, chronological: true },
      { id: "dhusar-pandulipi", label: "ধূসর পাণ্ডুলিপি — নিজস্ব কণ্ঠস্বর", motif: "ধুলোমাখা ধূসর পাণ্ডুলিপির পাতা", motifName: "page", collection: "ধূসর পাণ্ডুলিপি (১৯৩৬)", count: 8, chronological: true },
      { id: "banalata-sen", label: "বনলতা সেন — সন্ধ্যা ও অনন্ত", motif: "সন্ধ্যায় ঘরে-ফেরা পাখি; অন্ধকার", motifName: "bird", collection: "বনলতা সেন (১৯৪২)", count: 12, chronological: true },
      { id: "mahaprithibi-timir", label: "মহাপৃথিবী ও সাতটি তারার তিমির — অন্ধকারের বিস্তার", motif: "তারার ফাঁকে তিমির; বিস্তীর্ণ রাত", motifName: "stars", collection: "মহাপৃথিবী (১৯৪৪) · সাতটি তারার তিমির (১৯৪৮)", count: 10, chronological: true },
      { id: "rupasi-bangla", label: "রূপসী বাংলা — সমান্তরাল সবুজ", motif: "ধানসিঁড়ি নদী, মাছরাঙা, সবুজ বাংলা", motifName: "river", collection: "রূপসী বাংলা (১৯৫৭)", count: 9, chronological: false }
    ]
  },
  poems: [
    {
      id: "banalata-sen-poem", title: "বনলতা সেন", phase: "banalata-sen",
      collection: "বনলতা সেন", year: 1942, source: "বনলতা সেন, প্রথম সংস্করণ",
      themes: ["অন্ধকার", "পথ"], unverified: true,
      stanzas: [[
        "হাজার বছর ধরে আমি পথ হাঁটিতেছি পৃথিবীর পথে,",
        "সিংহল সমুদ্র থেকে নিশীথের অন্ধকারে মালয় সাগরে",
        "অনেক ঘুরেছি আমি; বিম্বিসার অশোকের ধূসর জগতে",
        "সেখানে ছিলাম আমি; আরো দূর অন্ধকারে বিদর্ভ নগরে;",
        "আমি ক্লান্ত প্রাণ এক, চারিদিকে জীবনের সমুদ্র সফেন,",
        "আমারে দুদণ্ড শান্তি দিয়েছিল নাটোরের বনলতা সেন।"
      ]],
      shareLines: [
        "আমি ক্লান্ত প্রাণ এক, চারিদিকে জীবনের সমুদ্র সফেন,",
        "আমারে দুদণ্ড শান্তি দিয়েছিল নাটোরের বনলতা সেন।"
      ]
    },
    {
      id: "kuri-bochor-pore", title: "কুড়ি বছর পরে", phase: "dhusar-pandulipi",
      collection: "ধূসর পাণ্ডুলিপি", year: 1936, source: null,
      themes: ["সময়", "স্মৃতি"], unverified: true,
      stanzas: [[
        "আবার বছর কুড়ি পরে তার সাথে দেখা হয় যদি!",
        "আবার বছর কুড়ি পরে —",
        "হয়তো ধানের ছড়ার পাশে",
        "কার্তিকের মাসে —"
      ]],
      shareLines: ["আবার বছর কুড়ি পরে তার সাথে দেখা হয় যদি!", "আবার বছর কুড়ি পরে —"]
    },
    {
      id: "abar-asibo-phire", title: "আবার আসিব ফিরে", phase: "rupasi-bangla",
      collection: "রূপসী বাংলা", year: 1957, source: "রূপসী বাংলা, প্রথম সংস্করণ",
      themes: ["নদী", "বাংলা"], unverified: true,
      stanzas: [[
        "আবার আসিব ফিরে ধানসিঁড়িটির তীরে — এই বাংলায়",
        "হয়তো মানুষ নয় — হয়তো বা শঙ্খচিল শালিখের বেশে;",
        "হয়তো ভোরের কাক হয়ে এই কার্তিকের নবান্নের দেশে",
        "কুয়াশার বুকে ভেসে একদিন আসিব এ কাঁঠাল-ছায়ায়;"
      ]],
      shareLines: ["আবার আসিব ফিরে ধানসিঁড়িটির তীরে — এই বাংলায়"]
    },
    {
      id: "aat-bochor-ager", title: "আট বছর আগের একদিন", phase: "mahaprithibi-timir",
      collection: "মহাপৃথিবী", year: 1944, source: null,
      themes: ["অন্ধকার", "মৃত্যু"], unverified: true,
      placeholder: true, placeholderLines: [0.88, 0.55, 0.74, 0.6, 0.82, 0.45],
      shareLines: null
    },
    {
      id: "nilima", title: "নীলিমা", phase: "jhara-palak",
      collection: "ঝরা পালক", year: 1927, source: null,
      themes: ["আকাশ"], unverified: true,
      placeholder: true, placeholderLines: [0.8, 0.66, 0.9, 0.5],
      shareLines: null
    }
  ],
  themes: ["অন্ধকার", "পথ", "সময়", "স্মৃতি", "নদী", "বাংলা", "মৃত্যু", "আকাশ"]
};
