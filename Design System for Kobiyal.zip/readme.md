# কবিয়াল (kobiyal) — Design System

A mobile-first, static, public-domain **Bengali poetry reading site** — the "Rekhta
experience" for Bengali verse. Free and non-commercial. Readers explore poems by poet
and by the *phases* of a poet's creative life; each phase has its own colour skin
derived from that period's imagery. The signature feel: **a calm near-white gallery
whose rooms (poet-phases) are lit in their own colour**, serif verse as the artwork,
quiet sans-serif labels on the walls.

Sources given:
- `uploads/kobiyal-design-system-brief.md` — the binding design brief (principles, palettes, deliverables).
- `uploads/kobiyal-strings-bn.json` — all reader-facing Bengali UI strings (copied to `data/strings-bn.json`). Use verbatim.
- Referenced but not attached: `kobiyal-codex-brief.md` (full poet/phase data + verse dataset).

## Five principles (binding)
1. **The text is the hero.** Verse leads; chrome recedes.
2. **Colour comes from the work, not onto it.** Phase palettes derive from the period's imagery — never invent decorative colour.
3. **Tasteful, never naggy.** Share affordances appear at genuine arrivals only; no popups, no timers.
4. **Mobile-first (390px); desktop is a serene widescreen of the *same* layout.**
5. **Honest.** Periodisation is a *reading*, not fact; attribution always present; the parallel strand (রূপসী বাংলা) is never flattened into a false progression.

## Colour architecture (the crux)
Two coexisting layers — see `tokens/colors.css`:
- **Shell** (`--shell-*`): constant near-white gallery chrome (header, nav, footer, page bg). `#FAFAF8` bg / `#2B2B28` graphite ink / `#E8E8E4` hairline. Never pure white.
- **Phase skin** (`--phase-*`): per-phase `{bg, ink, accent}` set by `data-skin="<phase-id>"` on a container. Themes ONLY reading surfaces: poet page body, poem view, active timeline segment, share card. All derived steps (`--phase-ink-muted`, `--phase-hairline`, `--phase-accent-deep`, `--phase-accent-soft`, `--phase-raised`, `--phase-veil`) recompute automatically via `color-mix` — **never hand-style a phase**.

Skins (Jibanananda Das): `jhara-palak`, `dhusar-pandulipi`, `banalata-sen` (dark), `mahaprithibi-timir` (near-black), `rupasi-bangla` (**parallel strand** — non-chronological; offset marker on the timeline, never inline with the progression).

**Contrast rule:** every `--phase-ink` on `--phase-bg` passes WCAG AA. Raw `--phase-accent` is for motifs, large display, markers, fills — for SMALL text always use `--phase-accent-deep`.

## CONTENT FUNDAMENTALS
- **Bengali only** for everything a reader sees. Keys/code stay English. Pull every label from `data/strings-bn.json` — never freelance copy.
- **Tone:** intimate, unhurried, native. আপনি-register imperatives ("কবি বেছে নিন", "এই পর্বে ঢুকুন"). Native verbs over loanwords: "ছড়িয়ে দিন" not শেয়ার, "ছবি নামিয়ে নিন" not ডাউনলোড, "লেখা টুকে নিন" not কপি. Even errors are gentle: "কিছু একটা গন্ডগোল হয়েছে।", loading is "একটু দাঁড়ান…".
- **Numerals:** ALL digits render in Bengali numerals (০১২৩৪৫৬৭৮৯) — `toBengaliDigits()`; never show Western digits to readers.
- **No fabricated Bengali, ever.** Never lorem ipsum, never invented or approximated verse. Use real verse from the kobiyal dataset; if unavailable, a clearly-marked neutral placeholder block shaped like verse. Texts pending verification carry "পাঠ যাচাই চলছে".
- **No emoji.** Proper nouns (ইনস্টাগ্রাম, @kobiyal) stay as-is.
- Honesty strings are part of the brand voice: "এই পর্ব-বিভাজন একটি পাঠ — কোনো ধ্রুব সত্য নয়।"

## VISUAL FOUNDATIONS
- **Type carries the shell/skin division.** Serif = the work: Noto Serif Bengali for verse, poet names, phase labels — everything inside the skin. Sans = the gallery: Hind Siliguri for nav, captions, chips, attribution. Don't cross the streams.
- **Verse type** is the largest, most cared-for type: `--text-verse`, line-height 1.9, measure `--measure-verse` (38rem), stanza gap `--space-6`. Check conjuncts (যুক্তাক্ষর: ক্ষ, জ্ঞ, ত্ত, ন্ধ) render cleanly.
- **Backgrounds:** flat colour fields only — shell near-white or phase `--phase-bg` flooding the page. No gradients, no textures, no imagery backgrounds.
- **Borders/edges:** 1px hairlines (`--shell-hairline` / `--phase-hairline`). Radius 4px (`--radius-card`) on cards, pill only on chips. Shadows nearly absent: `--shadow-card` is whisper-faint; `--shadow-lift` only for the share sheet.
- **Motifs:** restrained line-based marks (feather, manuscript page, homing bird, star-scatter, river-line) — flat, geometric, single-weight stroke, the visual logic of a sans-serif. Inline SVG with `stroke="currentColor"`, tinted `--phase-accent` inside a skin, `--shell-motif` in the shell. Sparse — one mark per surface, never clutter. See `components/reading/Motif.jsx`.
- **Motion:** one move — gentle illumination, `--dur-illuminate` (300ms) `--ease-illuminate`, on navigating/scrolling into a phase. Hover = ink/opacity shifts at `--dur-quick`; press = slight opacity dip. No bounces, no parallax, no infinite loops. Honors `prefers-reduced-motion`.
- **Layout:** 390px frame first; desktop (~1280) is the same single column, centered, with wider gutters (`--gutter-desktop`) — calm, not a re-layout. Generous vertical rhythm (`--space-7`–`--space-9` between sections).
- **Hover states:** text links shift to `--phase-accent-deep` or full ink; cards lift to `--phase-raised`/hairline darkens. Never scale-up animations.

## ICONOGRAPHY
- No icon font, no third-party icon set. The system's only "icons" are the five **line motifs** (single-weight inline SVG, currentColor) plus typographic marks: `·` interpuncts for metadata, `—` em-dashes, `‘ ’` Bengali-style quotes. Arrows are drawn glyphs (←) in Hind Siliguri.
- Never use emoji or decorative SVG illustration. If a new mark is needed, draw it in the same single-weight geometric stroke manner.

## Index
- `styles.css` — global entry (imports all tokens). Link this one file.
- `tokens/` — `colors.css` (shell + skins), `typography.css`, `spacing.css`, `motion.css`, `fonts.css` (Google Fonts: Noto Serif Bengali, Hind Siliguri).
- `data/strings-bn.json` — all UI strings (verbatim source of truth).
- `components/shell/` — SiteHeader, SiteFooter.
- `components/gallery/` — PoetCard, PhaseTimeline (the signature element).
- `components/reading/` — VerseBlock, AttributionBlock, ThemeChip, PeriodisationNote, HueNote, Motif.
- `components/share/` — ShareCard (1080×1350 Instagram), ShareBar.
- `guidelines/` — foundation specimen cards (Design System tab).
- `ui_kits/kobiyal/` — the site mock: home → poet (timeline) → poem reading views → theme page.
- `SKILL.md` — agent skill entry point.

## Verse policy for mockups (IMPORTANT)
Mockups here use canonical, public-domain Jibanananda Das lines (বনলতা সেন; আবার আসিব ফিরে; কুড়ি বছর পরে). They are well-known texts but MUST be verified against the kobiyal dataset / printed editions before shipping — the reading views show the "পাঠ যাচাই চলছে" badge for exactly this reason. Never add new Bengali verse without a verified source.
